﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.dgvIllinois = New System.Windows.Forms.DataGridView()
        Me.STOREIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.STORENAMEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ADDRESSDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CITYDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.STATEORPRODataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.POSTALCODEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PHONENUMBEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IllinoisBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataSet1 = New Conectores_Tarea02.DataSet1()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataSet4BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        'Me.DataSet4 = New Conectores_Tarea02.DataSet4()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.CodCliDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NombreDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DomicilioDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CodigoPostalDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TfoFaxDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClientesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataSet3 = New Conectores_Tarea02.DataSet3()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.CodCliDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NombreDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DomicilioDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CodigoPostalDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TfoFaxDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClientesBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DATOSDataSet = New Conectores_Tarea02.DATOSDataSet()
        Me.ClientesTableAdapter1 = New Conectores_Tarea02.DATOSDataSetTableAdapters.ClientesTableAdapter()
        Me.ClientesTableAdapter = New Conectores_Tarea02.DataSet3TableAdapters.ClientesTableAdapter()
        Me.IllinoisTableAdapter = New Conectores_Tarea02.DataSet1TableAdapters.illinoisTableAdapter()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.DataSet5 = New Conectores_Tarea02.DataSet5()
        Me.AutoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.AutoresTableAdapter = New Conectores_Tarea02.DataSet5TableAdapters.AutoresTableAdapter()
        Me.CodigoautorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NombreDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApellidosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EdadDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DireccionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DiscográficaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EstadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgvIllinois, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IllinoisBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSet4BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        'CType(Me.DataSet4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClientesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClientesBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DATOSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSet5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AutoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvIllinois
        '
        Me.dgvIllinois.AutoGenerateColumns = False
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvIllinois.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvIllinois.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvIllinois.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.STOREIDDataGridViewTextBoxColumn, Me.STORENAMEDataGridViewTextBoxColumn, Me.ADDRESSDataGridViewTextBoxColumn, Me.CITYDataGridViewTextBoxColumn, Me.STATEORPRODataGridViewTextBoxColumn, Me.POSTALCODEDataGridViewTextBoxColumn, Me.PHONENUMBEDataGridViewTextBoxColumn})
        Me.dgvIllinois.DataSource = Me.IllinoisBindingSource
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvIllinois.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgvIllinois.Location = New System.Drawing.Point(12, 25)
        Me.dgvIllinois.Name = "dgvIllinois"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvIllinois.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgvIllinois.Size = New System.Drawing.Size(842, 150)
        Me.dgvIllinois.TabIndex = 0
        Me.dgvIllinois.UseWaitCursor = True
        '
        'STOREIDDataGridViewTextBoxColumn
        '
        Me.STOREIDDataGridViewTextBoxColumn.DataPropertyName = "STOREID"
        Me.STOREIDDataGridViewTextBoxColumn.HeaderText = "STOREID"
        Me.STOREIDDataGridViewTextBoxColumn.Name = "STOREIDDataGridViewTextBoxColumn"
        '
        'STORENAMEDataGridViewTextBoxColumn
        '
        Me.STORENAMEDataGridViewTextBoxColumn.DataPropertyName = "STORENAME"
        Me.STORENAMEDataGridViewTextBoxColumn.HeaderText = "STORENAME"
        Me.STORENAMEDataGridViewTextBoxColumn.Name = "STORENAMEDataGridViewTextBoxColumn"
        '
        'ADDRESSDataGridViewTextBoxColumn
        '
        Me.ADDRESSDataGridViewTextBoxColumn.DataPropertyName = "ADDRESS"
        Me.ADDRESSDataGridViewTextBoxColumn.HeaderText = "ADDRESS"
        Me.ADDRESSDataGridViewTextBoxColumn.Name = "ADDRESSDataGridViewTextBoxColumn"
        '
        'CITYDataGridViewTextBoxColumn
        '
        Me.CITYDataGridViewTextBoxColumn.DataPropertyName = "CITY"
        Me.CITYDataGridViewTextBoxColumn.HeaderText = "CITY"
        Me.CITYDataGridViewTextBoxColumn.Name = "CITYDataGridViewTextBoxColumn"
        '
        'STATEORPRODataGridViewTextBoxColumn
        '
        Me.STATEORPRODataGridViewTextBoxColumn.DataPropertyName = "STATEORPRO"
        Me.STATEORPRODataGridViewTextBoxColumn.HeaderText = "STATEORPRO"
        Me.STATEORPRODataGridViewTextBoxColumn.Name = "STATEORPRODataGridViewTextBoxColumn"
        '
        'POSTALCODEDataGridViewTextBoxColumn
        '
        Me.POSTALCODEDataGridViewTextBoxColumn.DataPropertyName = "POSTALCODE"
        Me.POSTALCODEDataGridViewTextBoxColumn.HeaderText = "POSTALCODE"
        Me.POSTALCODEDataGridViewTextBoxColumn.Name = "POSTALCODEDataGridViewTextBoxColumn"
        '
        'PHONENUMBEDataGridViewTextBoxColumn
        '
        Me.PHONENUMBEDataGridViewTextBoxColumn.DataPropertyName = "PHONENUMBE"
        Me.PHONENUMBEDataGridViewTextBoxColumn.HeaderText = "PHONENUMBE"
        Me.PHONENUMBEDataGridViewTextBoxColumn.Name = "PHONENUMBEDataGridViewTextBoxColumn"
        '
        'IllinoisBindingSource
        '
        Me.IllinoisBindingSource.DataMember = "illinois"
        Me.IllinoisBindingSource.DataSource = Me.DataSet1
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "DataSet1"
        Me.DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(617, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Ejercicio1: La conexión deberás hacerla con un DSN de usuario a la base de datos " & _
    "Illinois a través del proveedor de datos ODBC"
        Me.Label1.UseWaitCursor = True
        '
        'DataSet4BindingSource
        '
        'Me.DataSet4BindingSource.DataSource = Me.DataSet4
        'Me.DataSet4BindingSource.Position = 0
        '
        'DataSet4
        '
        'Me.DataSet4.DataSetName = "DataSet4"
        'Me.DataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 189)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(842, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Ejercicio2: Prepara un formulario con un control DatagridView vinculado al archiv" & _
    "o de base de datos Autores (de Paradox). La conexión deberás hacerla con un DSN " & _
    "de sistema."
        Me.Label2.UseWaitCursor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 373)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(887, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Ejercicio3: ¿Crees que el proyecto del ejercicio 1 puede ser ejecutado por un usu" & _
    "ario diferente al que tenía la sesión iniciada en Windows cuando lo has creado? " & _
    "¿Por qué? Compruébalo."
        Me.Label3.UseWaitCursor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(15, 389)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(514, 97)
        Me.RichTextBox1.TabIndex = 9
        Me.RichTextBox1.Text = resources.GetString("RichTextBox1.Text")
        Me.RichTextBox1.UseWaitCursor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(554, 389)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(314, 228)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.UseWaitCursor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 628)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(590, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Ejercicio4a:  Prepara un formulario que muestre la base de datos datos.mdb (fiche" & _
    "ro de Access) usando un DSN de usuario."
        Me.Label4.UseWaitCursor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CodCliDataGridViewTextBoxColumn, Me.NombreDataGridViewTextBoxColumn, Me.DomicilioDataGridViewTextBoxColumn, Me.CodigoPostalDataGridViewTextBoxColumn, Me.TfoFaxDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.ClientesBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 644)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(842, 150)
        Me.DataGridView1.TabIndex = 12
        Me.DataGridView1.UseWaitCursor = True
        '
        'CodCliDataGridViewTextBoxColumn
        '
        Me.CodCliDataGridViewTextBoxColumn.DataPropertyName = "CodCli"
        Me.CodCliDataGridViewTextBoxColumn.HeaderText = "CodCli"
        Me.CodCliDataGridViewTextBoxColumn.Name = "CodCliDataGridViewTextBoxColumn"
        '
        'NombreDataGridViewTextBoxColumn
        '
        Me.NombreDataGridViewTextBoxColumn.DataPropertyName = "Nombre"
        Me.NombreDataGridViewTextBoxColumn.HeaderText = "Nombre"
        Me.NombreDataGridViewTextBoxColumn.Name = "NombreDataGridViewTextBoxColumn"
        '
        'DomicilioDataGridViewTextBoxColumn
        '
        Me.DomicilioDataGridViewTextBoxColumn.DataPropertyName = "Domicilio"
        Me.DomicilioDataGridViewTextBoxColumn.HeaderText = "Domicilio"
        Me.DomicilioDataGridViewTextBoxColumn.Name = "DomicilioDataGridViewTextBoxColumn"
        '
        'CodigoPostalDataGridViewTextBoxColumn
        '
        Me.CodigoPostalDataGridViewTextBoxColumn.DataPropertyName = "Codigo Postal"
        Me.CodigoPostalDataGridViewTextBoxColumn.HeaderText = "Codigo Postal"
        Me.CodigoPostalDataGridViewTextBoxColumn.Name = "CodigoPostalDataGridViewTextBoxColumn"
        '
        'TfoFaxDataGridViewTextBoxColumn
        '
        Me.TfoFaxDataGridViewTextBoxColumn.DataPropertyName = "TfoFax"
        Me.TfoFaxDataGridViewTextBoxColumn.HeaderText = "TfoFax"
        Me.TfoFaxDataGridViewTextBoxColumn.Name = "TfoFaxDataGridViewTextBoxColumn"
        '
        'ClientesBindingSource
        '
        Me.ClientesBindingSource.DataMember = "Clientes"
        Me.ClientesBindingSource.DataSource = Me.DataSet3
        '
        'DataSet3
        '
        Me.DataSet3.DataSetName = "DataSet3"
        Me.DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 807)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(274, 13)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Ejercicio4b: Ídem pero  esta vez hazlo mediante OLE DB"
        Me.Label5.UseWaitCursor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AutoGenerateColumns = False
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CodCliDataGridViewTextBoxColumn1, Me.NombreDataGridViewTextBoxColumn1, Me.DomicilioDataGridViewTextBoxColumn1, Me.CodigoPostalDataGridViewTextBoxColumn1, Me.TfoFaxDataGridViewTextBoxColumn1})
        Me.DataGridView2.DataSource = Me.ClientesBindingSource1
        Me.DataGridView2.Location = New System.Drawing.Point(12, 823)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(842, 150)
        Me.DataGridView2.TabIndex = 14
        Me.DataGridView2.UseWaitCursor = True
        '
        'CodCliDataGridViewTextBoxColumn1
        '
        Me.CodCliDataGridViewTextBoxColumn1.DataPropertyName = "CodCli"
        Me.CodCliDataGridViewTextBoxColumn1.HeaderText = "CodCli"
        Me.CodCliDataGridViewTextBoxColumn1.Name = "CodCliDataGridViewTextBoxColumn1"
        '
        'NombreDataGridViewTextBoxColumn1
        '
        Me.NombreDataGridViewTextBoxColumn1.DataPropertyName = "Nombre"
        Me.NombreDataGridViewTextBoxColumn1.HeaderText = "Nombre"
        Me.NombreDataGridViewTextBoxColumn1.Name = "NombreDataGridViewTextBoxColumn1"
        '
        'DomicilioDataGridViewTextBoxColumn1
        '
        Me.DomicilioDataGridViewTextBoxColumn1.DataPropertyName = "Domicilio"
        Me.DomicilioDataGridViewTextBoxColumn1.HeaderText = "Domicilio"
        Me.DomicilioDataGridViewTextBoxColumn1.Name = "DomicilioDataGridViewTextBoxColumn1"
        '
        'CodigoPostalDataGridViewTextBoxColumn1
        '
        Me.CodigoPostalDataGridViewTextBoxColumn1.DataPropertyName = "Codigo Postal"
        Me.CodigoPostalDataGridViewTextBoxColumn1.HeaderText = "Codigo Postal"
        Me.CodigoPostalDataGridViewTextBoxColumn1.Name = "CodigoPostalDataGridViewTextBoxColumn1"
        '
        'TfoFaxDataGridViewTextBoxColumn1
        '
        Me.TfoFaxDataGridViewTextBoxColumn1.DataPropertyName = "TfoFax"
        Me.TfoFaxDataGridViewTextBoxColumn1.HeaderText = "TfoFax"
        Me.TfoFaxDataGridViewTextBoxColumn1.Name = "TfoFaxDataGridViewTextBoxColumn1"
        '
        'ClientesBindingSource1
        '
        Me.ClientesBindingSource1.DataMember = "Clientes"
        Me.ClientesBindingSource1.DataSource = Me.DATOSDataSet
        '
        'DATOSDataSet
        '
        Me.DATOSDataSet.DataSetName = "DATOSDataSet"
        Me.DATOSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ClientesTableAdapter1
        '
        Me.ClientesTableAdapter1.ClearBeforeFill = True
        '
        'ClientesTableAdapter
        '
        Me.ClientesTableAdapter.ClearBeforeFill = True
        '
        'IllinoisTableAdapter
        '
        Me.IllinoisTableAdapter.ClearBeforeFill = True
        '
        'DataGridView3
        '
        Me.DataGridView3.AutoGenerateColumns = False
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CodigoautorDataGridViewTextBoxColumn, Me.NombreDataGridViewTextBoxColumn2, Me.ApellidosDataGridViewTextBoxColumn, Me.EdadDataGridViewTextBoxColumn, Me.DireccionDataGridViewTextBoxColumn, Me.DiscográficaDataGridViewTextBoxColumn, Me.EstadoDataGridViewTextBoxColumn})
        Me.DataGridView3.DataSource = Me.AutoresBindingSource
        Me.DataGridView3.Location = New System.Drawing.Point(12, 205)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(842, 150)
        Me.DataGridView3.TabIndex = 15
        '
        'DataSet5
        '
        Me.DataSet5.DataSetName = "DataSet5"
        Me.DataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'AutoresBindingSource
        '
        Me.AutoresBindingSource.DataMember = "Autores"
        Me.AutoresBindingSource.DataSource = Me.DataSet5
        '
        'AutoresTableAdapter
        '
        Me.AutoresTableAdapter.ClearBeforeFill = True
        '
        'CodigoautorDataGridViewTextBoxColumn
        '
        Me.CodigoautorDataGridViewTextBoxColumn.DataPropertyName = "codigo_autor"
        Me.CodigoautorDataGridViewTextBoxColumn.HeaderText = "codigo_autor"
        Me.CodigoautorDataGridViewTextBoxColumn.Name = "CodigoautorDataGridViewTextBoxColumn"
        '
        'NombreDataGridViewTextBoxColumn2
        '
        Me.NombreDataGridViewTextBoxColumn2.DataPropertyName = "Nombre"
        Me.NombreDataGridViewTextBoxColumn2.HeaderText = "Nombre"
        Me.NombreDataGridViewTextBoxColumn2.Name = "NombreDataGridViewTextBoxColumn2"
        '
        'ApellidosDataGridViewTextBoxColumn
        '
        Me.ApellidosDataGridViewTextBoxColumn.DataPropertyName = "Apellidos"
        Me.ApellidosDataGridViewTextBoxColumn.HeaderText = "Apellidos"
        Me.ApellidosDataGridViewTextBoxColumn.Name = "ApellidosDataGridViewTextBoxColumn"
        '
        'EdadDataGridViewTextBoxColumn
        '
        Me.EdadDataGridViewTextBoxColumn.DataPropertyName = "Edad"
        Me.EdadDataGridViewTextBoxColumn.HeaderText = "Edad"
        Me.EdadDataGridViewTextBoxColumn.Name = "EdadDataGridViewTextBoxColumn"
        '
        'DireccionDataGridViewTextBoxColumn
        '
        Me.DireccionDataGridViewTextBoxColumn.DataPropertyName = "Direccion"
        Me.DireccionDataGridViewTextBoxColumn.HeaderText = "Direccion"
        Me.DireccionDataGridViewTextBoxColumn.Name = "DireccionDataGridViewTextBoxColumn"
        '
        'DiscográficaDataGridViewTextBoxColumn
        '
        Me.DiscográficaDataGridViewTextBoxColumn.DataPropertyName = "Discográfica"
        Me.DiscográficaDataGridViewTextBoxColumn.HeaderText = "Discográfica"
        Me.DiscográficaDataGridViewTextBoxColumn.Name = "DiscográficaDataGridViewTextBoxColumn"
        '
        'EstadoDataGridViewTextBoxColumn
        '
        Me.EstadoDataGridViewTextBoxColumn.DataPropertyName = "Estado"
        Me.EstadoDataGridViewTextBoxColumn.HeaderText = "Estado"
        Me.EstadoDataGridViewTextBoxColumn.Name = "EstadoDataGridViewTextBoxColumn"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(904, 1061)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgvIllinois)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.UseWaitCursor = True
        CType(Me.dgvIllinois, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IllinoisBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSet4BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        'CType(Me.DataSet4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClientesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClientesBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DATOSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSet5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AutoresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvIllinois As System.Windows.Forms.DataGridView
    Friend WithEvents DataSet1 As Conectores_Tarea02.DataSet1
    Friend WithEvents IllinoisBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents IllinoisTableAdapter As Conectores_Tarea02.DataSet1TableAdapters.illinoisTableAdapter
    Friend WithEvents STOREIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents STORENAMEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ADDRESSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CITYDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents STATEORPRODataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents POSTALCODEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PHONENUMBEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataSet3 As Conectores_Tarea02.DataSet3
    Friend WithEvents ClientesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ClientesTableAdapter As Conectores_Tarea02.DataSet3TableAdapters.ClientesTableAdapter
    Friend WithEvents CodCliDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NombreDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DomicilioDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CodigoPostalDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TfoFaxDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataSet4BindingSource As System.Windows.Forms.BindingSource
    'Friend WithEvents DataSet4 As Conectores_Tarea02.DataSet4
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents DATOSDataSet As Conectores_Tarea02.DATOSDataSet
    Friend WithEvents ClientesBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents ClientesTableAdapter1 As Conectores_Tarea02.DATOSDataSetTableAdapters.ClientesTableAdapter
    Friend WithEvents CodCliDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NombreDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DomicilioDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CodigoPostalDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TfoFaxDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents DataSet5 As Conectores_Tarea02.DataSet5
    Friend WithEvents AutoresBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents AutoresTableAdapter As Conectores_Tarea02.DataSet5TableAdapters.AutoresTableAdapter
    Friend WithEvents CodigoautorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NombreDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ApellidosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EdadDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DireccionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DiscográficaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EstadoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
