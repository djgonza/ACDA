﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.AuidDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AulnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AufnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhoneDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ZipDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContractDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.AuthorsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAuthors = New Conectores_Tarea03.dsAuthors()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.EmployeeIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TitleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TitleOfCourtesyDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BirthDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HireDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RegionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PostalCodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CountryDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HomePhoneDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExtensionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhotoDataGridViewImageColumn = New System.Windows.Forms.DataGridViewImageColumn()
        Me.NotesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReportsToDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhotoPathDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmployeesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsEmployeesNS = New Conectores_Tarea03.dsEmployeesNS()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.AuidDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AulnameDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AufnameDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhoneDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StateDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ZipDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContractDataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.AuthorsBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAuthorsEjercicio3 = New Conectores_Tarea03.dsAuthorsEjercicio3()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.EmployeeIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastNameDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstNameDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TitleDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TitleOfCourtesyDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BirthDateDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HireDateDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RegionDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PostalCodeDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CountryDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HomePhoneDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExtensionDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhotoDataGridViewImageColumn1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.NotesDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReportsToDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhotoPathDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmployeesBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsEjercicio4 = New Conectores_Tarea03.dsEjercicio4()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView()
        Me.AuidDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AulnameDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AufnameDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhoneDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddressDataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StateDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ZipDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContractDataGridViewCheckBoxColumn2 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.AuthorsBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsEjercicio6 = New Conectores_Tarea03.dsEjercicio6()
        Me.AuthorsTableAdapter2 = New Conectores_Tarea03.dsEjercicio6TableAdapters.authorsTableAdapter()
        Me.EmployeesTableAdapter1 = New Conectores_Tarea03.dsEjercicio4TableAdapters.EmployeesTableAdapter()
        Me.AuthorsTableAdapter1 = New Conectores_Tarea03.dsAuthorsEjercicio3TableAdapters.authorsTableAdapter()
        Me.EmployeesTableAdapter = New Conectores_Tarea03.dsEmployeesNSTableAdapters.EmployeesTableAdapter()
        Me.AuthorsTableAdapter = New Conectores_Tarea03.dsAuthorsTableAdapters.authorsTableAdapter()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AuthorsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAuthors, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsEmployeesNS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AuthorsBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAuthorsEjercicio3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeesBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsEjercicio4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AuthorsBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsEjercicio6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Ejercicio1: "
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AuidDataGridViewTextBoxColumn, Me.AulnameDataGridViewTextBoxColumn, Me.AufnameDataGridViewTextBoxColumn, Me.PhoneDataGridViewTextBoxColumn, Me.AddressDataGridViewTextBoxColumn, Me.CityDataGridViewTextBoxColumn, Me.StateDataGridViewTextBoxColumn, Me.ZipDataGridViewTextBoxColumn, Me.ContractDataGridViewCheckBoxColumn})
        Me.DataGridView1.DataSource = Me.AuthorsBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 25)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(952, 150)
        Me.DataGridView1.TabIndex = 1
        '
        'AuidDataGridViewTextBoxColumn
        '
        Me.AuidDataGridViewTextBoxColumn.DataPropertyName = "au_id"
        Me.AuidDataGridViewTextBoxColumn.HeaderText = "au_id"
        Me.AuidDataGridViewTextBoxColumn.Name = "AuidDataGridViewTextBoxColumn"
        '
        'AulnameDataGridViewTextBoxColumn
        '
        Me.AulnameDataGridViewTextBoxColumn.DataPropertyName = "au_lname"
        Me.AulnameDataGridViewTextBoxColumn.HeaderText = "au_lname"
        Me.AulnameDataGridViewTextBoxColumn.Name = "AulnameDataGridViewTextBoxColumn"
        '
        'AufnameDataGridViewTextBoxColumn
        '
        Me.AufnameDataGridViewTextBoxColumn.DataPropertyName = "au_fname"
        Me.AufnameDataGridViewTextBoxColumn.HeaderText = "au_fname"
        Me.AufnameDataGridViewTextBoxColumn.Name = "AufnameDataGridViewTextBoxColumn"
        '
        'PhoneDataGridViewTextBoxColumn
        '
        Me.PhoneDataGridViewTextBoxColumn.DataPropertyName = "phone"
        Me.PhoneDataGridViewTextBoxColumn.HeaderText = "phone"
        Me.PhoneDataGridViewTextBoxColumn.Name = "PhoneDataGridViewTextBoxColumn"
        '
        'AddressDataGridViewTextBoxColumn
        '
        Me.AddressDataGridViewTextBoxColumn.DataPropertyName = "address"
        Me.AddressDataGridViewTextBoxColumn.HeaderText = "address"
        Me.AddressDataGridViewTextBoxColumn.Name = "AddressDataGridViewTextBoxColumn"
        '
        'CityDataGridViewTextBoxColumn
        '
        Me.CityDataGridViewTextBoxColumn.DataPropertyName = "city"
        Me.CityDataGridViewTextBoxColumn.HeaderText = "city"
        Me.CityDataGridViewTextBoxColumn.Name = "CityDataGridViewTextBoxColumn"
        '
        'StateDataGridViewTextBoxColumn
        '
        Me.StateDataGridViewTextBoxColumn.DataPropertyName = "state"
        Me.StateDataGridViewTextBoxColumn.HeaderText = "state"
        Me.StateDataGridViewTextBoxColumn.Name = "StateDataGridViewTextBoxColumn"
        '
        'ZipDataGridViewTextBoxColumn
        '
        Me.ZipDataGridViewTextBoxColumn.DataPropertyName = "zip"
        Me.ZipDataGridViewTextBoxColumn.HeaderText = "zip"
        Me.ZipDataGridViewTextBoxColumn.Name = "ZipDataGridViewTextBoxColumn"
        '
        'ContractDataGridViewCheckBoxColumn
        '
        Me.ContractDataGridViewCheckBoxColumn.DataPropertyName = "contract"
        Me.ContractDataGridViewCheckBoxColumn.HeaderText = "contract"
        Me.ContractDataGridViewCheckBoxColumn.Name = "ContractDataGridViewCheckBoxColumn"
        '
        'AuthorsBindingSource
        '
        Me.AuthorsBindingSource.DataMember = "authors"
        Me.AuthorsBindingSource.DataSource = Me.DsAuthors
        '
        'DsAuthors
        '
        Me.DsAuthors.DataSetName = "dsAuthors"
        Me.DsAuthors.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 190)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Ejercicio2: "
        '
        'DataGridView2
        '
        Me.DataGridView2.AutoGenerateColumns = False
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.EmployeeIDDataGridViewTextBoxColumn, Me.LastNameDataGridViewTextBoxColumn, Me.FirstNameDataGridViewTextBoxColumn, Me.TitleDataGridViewTextBoxColumn, Me.TitleOfCourtesyDataGridViewTextBoxColumn, Me.BirthDateDataGridViewTextBoxColumn, Me.HireDateDataGridViewTextBoxColumn, Me.AddressDataGridViewTextBoxColumn1, Me.CityDataGridViewTextBoxColumn1, Me.RegionDataGridViewTextBoxColumn, Me.PostalCodeDataGridViewTextBoxColumn, Me.CountryDataGridViewTextBoxColumn, Me.HomePhoneDataGridViewTextBoxColumn, Me.ExtensionDataGridViewTextBoxColumn, Me.PhotoDataGridViewImageColumn, Me.NotesDataGridViewTextBoxColumn, Me.ReportsToDataGridViewTextBoxColumn, Me.PhotoPathDataGridViewTextBoxColumn})
        Me.DataGridView2.DataSource = Me.EmployeesBindingSource
        Me.DataGridView2.Location = New System.Drawing.Point(12, 206)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(1144, 150)
        Me.DataGridView2.TabIndex = 3
        '
        'EmployeeIDDataGridViewTextBoxColumn
        '
        Me.EmployeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID"
        Me.EmployeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID"
        Me.EmployeeIDDataGridViewTextBoxColumn.Name = "EmployeeIDDataGridViewTextBoxColumn"
        Me.EmployeeIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'LastNameDataGridViewTextBoxColumn
        '
        Me.LastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.HeaderText = "LastName"
        Me.LastNameDataGridViewTextBoxColumn.Name = "LastNameDataGridViewTextBoxColumn"
        '
        'FirstNameDataGridViewTextBoxColumn
        '
        Me.FirstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.HeaderText = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn.Name = "FirstNameDataGridViewTextBoxColumn"
        '
        'TitleDataGridViewTextBoxColumn
        '
        Me.TitleDataGridViewTextBoxColumn.DataPropertyName = "Title"
        Me.TitleDataGridViewTextBoxColumn.HeaderText = "Title"
        Me.TitleDataGridViewTextBoxColumn.Name = "TitleDataGridViewTextBoxColumn"
        '
        'TitleOfCourtesyDataGridViewTextBoxColumn
        '
        Me.TitleOfCourtesyDataGridViewTextBoxColumn.DataPropertyName = "TitleOfCourtesy"
        Me.TitleOfCourtesyDataGridViewTextBoxColumn.HeaderText = "TitleOfCourtesy"
        Me.TitleOfCourtesyDataGridViewTextBoxColumn.Name = "TitleOfCourtesyDataGridViewTextBoxColumn"
        '
        'BirthDateDataGridViewTextBoxColumn
        '
        Me.BirthDateDataGridViewTextBoxColumn.DataPropertyName = "BirthDate"
        Me.BirthDateDataGridViewTextBoxColumn.HeaderText = "BirthDate"
        Me.BirthDateDataGridViewTextBoxColumn.Name = "BirthDateDataGridViewTextBoxColumn"
        '
        'HireDateDataGridViewTextBoxColumn
        '
        Me.HireDateDataGridViewTextBoxColumn.DataPropertyName = "HireDate"
        Me.HireDateDataGridViewTextBoxColumn.HeaderText = "HireDate"
        Me.HireDateDataGridViewTextBoxColumn.Name = "HireDateDataGridViewTextBoxColumn"
        '
        'AddressDataGridViewTextBoxColumn1
        '
        Me.AddressDataGridViewTextBoxColumn1.DataPropertyName = "Address"
        Me.AddressDataGridViewTextBoxColumn1.HeaderText = "Address"
        Me.AddressDataGridViewTextBoxColumn1.Name = "AddressDataGridViewTextBoxColumn1"
        '
        'CityDataGridViewTextBoxColumn1
        '
        Me.CityDataGridViewTextBoxColumn1.DataPropertyName = "City"
        Me.CityDataGridViewTextBoxColumn1.HeaderText = "City"
        Me.CityDataGridViewTextBoxColumn1.Name = "CityDataGridViewTextBoxColumn1"
        '
        'RegionDataGridViewTextBoxColumn
        '
        Me.RegionDataGridViewTextBoxColumn.DataPropertyName = "Region"
        Me.RegionDataGridViewTextBoxColumn.HeaderText = "Region"
        Me.RegionDataGridViewTextBoxColumn.Name = "RegionDataGridViewTextBoxColumn"
        '
        'PostalCodeDataGridViewTextBoxColumn
        '
        Me.PostalCodeDataGridViewTextBoxColumn.DataPropertyName = "PostalCode"
        Me.PostalCodeDataGridViewTextBoxColumn.HeaderText = "PostalCode"
        Me.PostalCodeDataGridViewTextBoxColumn.Name = "PostalCodeDataGridViewTextBoxColumn"
        '
        'CountryDataGridViewTextBoxColumn
        '
        Me.CountryDataGridViewTextBoxColumn.DataPropertyName = "Country"
        Me.CountryDataGridViewTextBoxColumn.HeaderText = "Country"
        Me.CountryDataGridViewTextBoxColumn.Name = "CountryDataGridViewTextBoxColumn"
        '
        'HomePhoneDataGridViewTextBoxColumn
        '
        Me.HomePhoneDataGridViewTextBoxColumn.DataPropertyName = "HomePhone"
        Me.HomePhoneDataGridViewTextBoxColumn.HeaderText = "HomePhone"
        Me.HomePhoneDataGridViewTextBoxColumn.Name = "HomePhoneDataGridViewTextBoxColumn"
        '
        'ExtensionDataGridViewTextBoxColumn
        '
        Me.ExtensionDataGridViewTextBoxColumn.DataPropertyName = "Extension"
        Me.ExtensionDataGridViewTextBoxColumn.HeaderText = "Extension"
        Me.ExtensionDataGridViewTextBoxColumn.Name = "ExtensionDataGridViewTextBoxColumn"
        '
        'PhotoDataGridViewImageColumn
        '
        Me.PhotoDataGridViewImageColumn.DataPropertyName = "Photo"
        Me.PhotoDataGridViewImageColumn.HeaderText = "Photo"
        Me.PhotoDataGridViewImageColumn.Name = "PhotoDataGridViewImageColumn"
        '
        'NotesDataGridViewTextBoxColumn
        '
        Me.NotesDataGridViewTextBoxColumn.DataPropertyName = "Notes"
        Me.NotesDataGridViewTextBoxColumn.HeaderText = "Notes"
        Me.NotesDataGridViewTextBoxColumn.Name = "NotesDataGridViewTextBoxColumn"
        '
        'ReportsToDataGridViewTextBoxColumn
        '
        Me.ReportsToDataGridViewTextBoxColumn.DataPropertyName = "ReportsTo"
        Me.ReportsToDataGridViewTextBoxColumn.HeaderText = "ReportsTo"
        Me.ReportsToDataGridViewTextBoxColumn.Name = "ReportsToDataGridViewTextBoxColumn"
        '
        'PhotoPathDataGridViewTextBoxColumn
        '
        Me.PhotoPathDataGridViewTextBoxColumn.DataPropertyName = "PhotoPath"
        Me.PhotoPathDataGridViewTextBoxColumn.HeaderText = "PhotoPath"
        Me.PhotoPathDataGridViewTextBoxColumn.Name = "PhotoPathDataGridViewTextBoxColumn"
        '
        'EmployeesBindingSource
        '
        Me.EmployeesBindingSource.DataMember = "Employees"
        Me.EmployeesBindingSource.DataSource = Me.DsEmployeesNS
        '
        'DsEmployeesNS
        '
        Me.DsEmployeesNS.DataSetName = "dsEmployeesNS"
        Me.DsEmployeesNS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 372)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Ejercicio3: "
        '
        'DataGridView3
        '
        Me.DataGridView3.AutoGenerateColumns = False
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AuidDataGridViewTextBoxColumn1, Me.AulnameDataGridViewTextBoxColumn1, Me.AufnameDataGridViewTextBoxColumn1, Me.PhoneDataGridViewTextBoxColumn1, Me.AddressDataGridViewTextBoxColumn2, Me.CityDataGridViewTextBoxColumn2, Me.StateDataGridViewTextBoxColumn1, Me.ZipDataGridViewTextBoxColumn1, Me.ContractDataGridViewCheckBoxColumn1})
        Me.DataGridView3.DataSource = Me.AuthorsBindingSource1
        Me.DataGridView3.Location = New System.Drawing.Point(12, 388)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(952, 150)
        Me.DataGridView3.TabIndex = 5
        '
        'AuidDataGridViewTextBoxColumn1
        '
        Me.AuidDataGridViewTextBoxColumn1.DataPropertyName = "au_id"
        Me.AuidDataGridViewTextBoxColumn1.HeaderText = "au_id"
        Me.AuidDataGridViewTextBoxColumn1.Name = "AuidDataGridViewTextBoxColumn1"
        '
        'AulnameDataGridViewTextBoxColumn1
        '
        Me.AulnameDataGridViewTextBoxColumn1.DataPropertyName = "au_lname"
        Me.AulnameDataGridViewTextBoxColumn1.HeaderText = "au_lname"
        Me.AulnameDataGridViewTextBoxColumn1.Name = "AulnameDataGridViewTextBoxColumn1"
        '
        'AufnameDataGridViewTextBoxColumn1
        '
        Me.AufnameDataGridViewTextBoxColumn1.DataPropertyName = "au_fname"
        Me.AufnameDataGridViewTextBoxColumn1.HeaderText = "au_fname"
        Me.AufnameDataGridViewTextBoxColumn1.Name = "AufnameDataGridViewTextBoxColumn1"
        '
        'PhoneDataGridViewTextBoxColumn1
        '
        Me.PhoneDataGridViewTextBoxColumn1.DataPropertyName = "phone"
        Me.PhoneDataGridViewTextBoxColumn1.HeaderText = "phone"
        Me.PhoneDataGridViewTextBoxColumn1.Name = "PhoneDataGridViewTextBoxColumn1"
        '
        'AddressDataGridViewTextBoxColumn2
        '
        Me.AddressDataGridViewTextBoxColumn2.DataPropertyName = "address"
        Me.AddressDataGridViewTextBoxColumn2.HeaderText = "address"
        Me.AddressDataGridViewTextBoxColumn2.Name = "AddressDataGridViewTextBoxColumn2"
        '
        'CityDataGridViewTextBoxColumn2
        '
        Me.CityDataGridViewTextBoxColumn2.DataPropertyName = "city"
        Me.CityDataGridViewTextBoxColumn2.HeaderText = "city"
        Me.CityDataGridViewTextBoxColumn2.Name = "CityDataGridViewTextBoxColumn2"
        '
        'StateDataGridViewTextBoxColumn1
        '
        Me.StateDataGridViewTextBoxColumn1.DataPropertyName = "state"
        Me.StateDataGridViewTextBoxColumn1.HeaderText = "state"
        Me.StateDataGridViewTextBoxColumn1.Name = "StateDataGridViewTextBoxColumn1"
        '
        'ZipDataGridViewTextBoxColumn1
        '
        Me.ZipDataGridViewTextBoxColumn1.DataPropertyName = "zip"
        Me.ZipDataGridViewTextBoxColumn1.HeaderText = "zip"
        Me.ZipDataGridViewTextBoxColumn1.Name = "ZipDataGridViewTextBoxColumn1"
        '
        'ContractDataGridViewCheckBoxColumn1
        '
        Me.ContractDataGridViewCheckBoxColumn1.DataPropertyName = "contract"
        Me.ContractDataGridViewCheckBoxColumn1.HeaderText = "contract"
        Me.ContractDataGridViewCheckBoxColumn1.Name = "ContractDataGridViewCheckBoxColumn1"
        '
        'AuthorsBindingSource1
        '
        Me.AuthorsBindingSource1.DataMember = "authors"
        Me.AuthorsBindingSource1.DataSource = Me.DsAuthorsEjercicio3
        '
        'DsAuthorsEjercicio3
        '
        Me.DsAuthorsEjercicio3.DataSetName = "dsAuthorsEjercicio3"
        Me.DsAuthorsEjercicio3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 555)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Ejercicio4: "
        '
        'DataGridView4
        '
        Me.DataGridView4.AutoGenerateColumns = False
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.EmployeeIDDataGridViewTextBoxColumn1, Me.LastNameDataGridViewTextBoxColumn1, Me.FirstNameDataGridViewTextBoxColumn1, Me.TitleDataGridViewTextBoxColumn1, Me.TitleOfCourtesyDataGridViewTextBoxColumn1, Me.BirthDateDataGridViewTextBoxColumn1, Me.HireDateDataGridViewTextBoxColumn1, Me.AddressDataGridViewTextBoxColumn3, Me.CityDataGridViewTextBoxColumn3, Me.RegionDataGridViewTextBoxColumn1, Me.PostalCodeDataGridViewTextBoxColumn1, Me.CountryDataGridViewTextBoxColumn1, Me.HomePhoneDataGridViewTextBoxColumn1, Me.ExtensionDataGridViewTextBoxColumn1, Me.PhotoDataGridViewImageColumn1, Me.NotesDataGridViewTextBoxColumn1, Me.ReportsToDataGridViewTextBoxColumn1, Me.PhotoPathDataGridViewTextBoxColumn1})
        Me.DataGridView4.DataSource = Me.EmployeesBindingSource1
        Me.DataGridView4.Location = New System.Drawing.Point(15, 571)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.Size = New System.Drawing.Size(1141, 150)
        Me.DataGridView4.TabIndex = 7
        '
        'EmployeeIDDataGridViewTextBoxColumn1
        '
        Me.EmployeeIDDataGridViewTextBoxColumn1.DataPropertyName = "EmployeeID"
        Me.EmployeeIDDataGridViewTextBoxColumn1.HeaderText = "EmployeeID"
        Me.EmployeeIDDataGridViewTextBoxColumn1.Name = "EmployeeIDDataGridViewTextBoxColumn1"
        Me.EmployeeIDDataGridViewTextBoxColumn1.ReadOnly = True
        '
        'LastNameDataGridViewTextBoxColumn1
        '
        Me.LastNameDataGridViewTextBoxColumn1.DataPropertyName = "LastName"
        Me.LastNameDataGridViewTextBoxColumn1.HeaderText = "LastName"
        Me.LastNameDataGridViewTextBoxColumn1.Name = "LastNameDataGridViewTextBoxColumn1"
        '
        'FirstNameDataGridViewTextBoxColumn1
        '
        Me.FirstNameDataGridViewTextBoxColumn1.DataPropertyName = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn1.HeaderText = "FirstName"
        Me.FirstNameDataGridViewTextBoxColumn1.Name = "FirstNameDataGridViewTextBoxColumn1"
        '
        'TitleDataGridViewTextBoxColumn1
        '
        Me.TitleDataGridViewTextBoxColumn1.DataPropertyName = "Title"
        Me.TitleDataGridViewTextBoxColumn1.HeaderText = "Title"
        Me.TitleDataGridViewTextBoxColumn1.Name = "TitleDataGridViewTextBoxColumn1"
        '
        'TitleOfCourtesyDataGridViewTextBoxColumn1
        '
        Me.TitleOfCourtesyDataGridViewTextBoxColumn1.DataPropertyName = "TitleOfCourtesy"
        Me.TitleOfCourtesyDataGridViewTextBoxColumn1.HeaderText = "TitleOfCourtesy"
        Me.TitleOfCourtesyDataGridViewTextBoxColumn1.Name = "TitleOfCourtesyDataGridViewTextBoxColumn1"
        '
        'BirthDateDataGridViewTextBoxColumn1
        '
        Me.BirthDateDataGridViewTextBoxColumn1.DataPropertyName = "BirthDate"
        Me.BirthDateDataGridViewTextBoxColumn1.HeaderText = "BirthDate"
        Me.BirthDateDataGridViewTextBoxColumn1.Name = "BirthDateDataGridViewTextBoxColumn1"
        '
        'HireDateDataGridViewTextBoxColumn1
        '
        Me.HireDateDataGridViewTextBoxColumn1.DataPropertyName = "HireDate"
        Me.HireDateDataGridViewTextBoxColumn1.HeaderText = "HireDate"
        Me.HireDateDataGridViewTextBoxColumn1.Name = "HireDateDataGridViewTextBoxColumn1"
        '
        'AddressDataGridViewTextBoxColumn3
        '
        Me.AddressDataGridViewTextBoxColumn3.DataPropertyName = "Address"
        Me.AddressDataGridViewTextBoxColumn3.HeaderText = "Address"
        Me.AddressDataGridViewTextBoxColumn3.Name = "AddressDataGridViewTextBoxColumn3"
        '
        'CityDataGridViewTextBoxColumn3
        '
        Me.CityDataGridViewTextBoxColumn3.DataPropertyName = "City"
        Me.CityDataGridViewTextBoxColumn3.HeaderText = "City"
        Me.CityDataGridViewTextBoxColumn3.Name = "CityDataGridViewTextBoxColumn3"
        '
        'RegionDataGridViewTextBoxColumn1
        '
        Me.RegionDataGridViewTextBoxColumn1.DataPropertyName = "Region"
        Me.RegionDataGridViewTextBoxColumn1.HeaderText = "Region"
        Me.RegionDataGridViewTextBoxColumn1.Name = "RegionDataGridViewTextBoxColumn1"
        '
        'PostalCodeDataGridViewTextBoxColumn1
        '
        Me.PostalCodeDataGridViewTextBoxColumn1.DataPropertyName = "PostalCode"
        Me.PostalCodeDataGridViewTextBoxColumn1.HeaderText = "PostalCode"
        Me.PostalCodeDataGridViewTextBoxColumn1.Name = "PostalCodeDataGridViewTextBoxColumn1"
        '
        'CountryDataGridViewTextBoxColumn1
        '
        Me.CountryDataGridViewTextBoxColumn1.DataPropertyName = "Country"
        Me.CountryDataGridViewTextBoxColumn1.HeaderText = "Country"
        Me.CountryDataGridViewTextBoxColumn1.Name = "CountryDataGridViewTextBoxColumn1"
        '
        'HomePhoneDataGridViewTextBoxColumn1
        '
        Me.HomePhoneDataGridViewTextBoxColumn1.DataPropertyName = "HomePhone"
        Me.HomePhoneDataGridViewTextBoxColumn1.HeaderText = "HomePhone"
        Me.HomePhoneDataGridViewTextBoxColumn1.Name = "HomePhoneDataGridViewTextBoxColumn1"
        '
        'ExtensionDataGridViewTextBoxColumn1
        '
        Me.ExtensionDataGridViewTextBoxColumn1.DataPropertyName = "Extension"
        Me.ExtensionDataGridViewTextBoxColumn1.HeaderText = "Extension"
        Me.ExtensionDataGridViewTextBoxColumn1.Name = "ExtensionDataGridViewTextBoxColumn1"
        '
        'PhotoDataGridViewImageColumn1
        '
        Me.PhotoDataGridViewImageColumn1.DataPropertyName = "Photo"
        Me.PhotoDataGridViewImageColumn1.HeaderText = "Photo"
        Me.PhotoDataGridViewImageColumn1.Name = "PhotoDataGridViewImageColumn1"
        '
        'NotesDataGridViewTextBoxColumn1
        '
        Me.NotesDataGridViewTextBoxColumn1.DataPropertyName = "Notes"
        Me.NotesDataGridViewTextBoxColumn1.HeaderText = "Notes"
        Me.NotesDataGridViewTextBoxColumn1.Name = "NotesDataGridViewTextBoxColumn1"
        '
        'ReportsToDataGridViewTextBoxColumn1
        '
        Me.ReportsToDataGridViewTextBoxColumn1.DataPropertyName = "ReportsTo"
        Me.ReportsToDataGridViewTextBoxColumn1.HeaderText = "ReportsTo"
        Me.ReportsToDataGridViewTextBoxColumn1.Name = "ReportsToDataGridViewTextBoxColumn1"
        '
        'PhotoPathDataGridViewTextBoxColumn1
        '
        Me.PhotoPathDataGridViewTextBoxColumn1.DataPropertyName = "PhotoPath"
        Me.PhotoPathDataGridViewTextBoxColumn1.HeaderText = "PhotoPath"
        Me.PhotoPathDataGridViewTextBoxColumn1.Name = "PhotoPathDataGridViewTextBoxColumn1"
        '
        'EmployeesBindingSource1
        '
        Me.EmployeesBindingSource1.DataMember = "Employees"
        Me.EmployeesBindingSource1.DataSource = Me.DsEjercicio4
        '
        'DsEjercicio4
        '
        Me.DsEjercicio4.DataSetName = "dsEjercicio4"
        Me.DsEjercicio4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 740)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Ejercicio6: "
        '
        'DataGridView5
        '
        Me.DataGridView5.AutoGenerateColumns = False
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AuidDataGridViewTextBoxColumn2, Me.AulnameDataGridViewTextBoxColumn2, Me.AufnameDataGridViewTextBoxColumn2, Me.PhoneDataGridViewTextBoxColumn2, Me.AddressDataGridViewTextBoxColumn4, Me.CityDataGridViewTextBoxColumn4, Me.StateDataGridViewTextBoxColumn2, Me.ZipDataGridViewTextBoxColumn2, Me.ContractDataGridViewCheckBoxColumn2})
        Me.DataGridView5.DataSource = Me.AuthorsBindingSource2
        Me.DataGridView5.Location = New System.Drawing.Point(15, 756)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.Size = New System.Drawing.Size(949, 150)
        Me.DataGridView5.TabIndex = 9
        '
        'AuidDataGridViewTextBoxColumn2
        '
        Me.AuidDataGridViewTextBoxColumn2.DataPropertyName = "au_id"
        Me.AuidDataGridViewTextBoxColumn2.HeaderText = "au_id"
        Me.AuidDataGridViewTextBoxColumn2.Name = "AuidDataGridViewTextBoxColumn2"
        '
        'AulnameDataGridViewTextBoxColumn2
        '
        Me.AulnameDataGridViewTextBoxColumn2.DataPropertyName = "au_lname"
        Me.AulnameDataGridViewTextBoxColumn2.HeaderText = "au_lname"
        Me.AulnameDataGridViewTextBoxColumn2.Name = "AulnameDataGridViewTextBoxColumn2"
        '
        'AufnameDataGridViewTextBoxColumn2
        '
        Me.AufnameDataGridViewTextBoxColumn2.DataPropertyName = "au_fname"
        Me.AufnameDataGridViewTextBoxColumn2.HeaderText = "au_fname"
        Me.AufnameDataGridViewTextBoxColumn2.Name = "AufnameDataGridViewTextBoxColumn2"
        '
        'PhoneDataGridViewTextBoxColumn2
        '
        Me.PhoneDataGridViewTextBoxColumn2.DataPropertyName = "phone"
        Me.PhoneDataGridViewTextBoxColumn2.HeaderText = "phone"
        Me.PhoneDataGridViewTextBoxColumn2.Name = "PhoneDataGridViewTextBoxColumn2"
        '
        'AddressDataGridViewTextBoxColumn4
        '
        Me.AddressDataGridViewTextBoxColumn4.DataPropertyName = "address"
        Me.AddressDataGridViewTextBoxColumn4.HeaderText = "address"
        Me.AddressDataGridViewTextBoxColumn4.Name = "AddressDataGridViewTextBoxColumn4"
        '
        'CityDataGridViewTextBoxColumn4
        '
        Me.CityDataGridViewTextBoxColumn4.DataPropertyName = "city"
        Me.CityDataGridViewTextBoxColumn4.HeaderText = "city"
        Me.CityDataGridViewTextBoxColumn4.Name = "CityDataGridViewTextBoxColumn4"
        '
        'StateDataGridViewTextBoxColumn2
        '
        Me.StateDataGridViewTextBoxColumn2.DataPropertyName = "state"
        Me.StateDataGridViewTextBoxColumn2.HeaderText = "state"
        Me.StateDataGridViewTextBoxColumn2.Name = "StateDataGridViewTextBoxColumn2"
        '
        'ZipDataGridViewTextBoxColumn2
        '
        Me.ZipDataGridViewTextBoxColumn2.DataPropertyName = "zip"
        Me.ZipDataGridViewTextBoxColumn2.HeaderText = "zip"
        Me.ZipDataGridViewTextBoxColumn2.Name = "ZipDataGridViewTextBoxColumn2"
        '
        'ContractDataGridViewCheckBoxColumn2
        '
        Me.ContractDataGridViewCheckBoxColumn2.DataPropertyName = "contract"
        Me.ContractDataGridViewCheckBoxColumn2.HeaderText = "contract"
        Me.ContractDataGridViewCheckBoxColumn2.Name = "ContractDataGridViewCheckBoxColumn2"
        '
        'AuthorsBindingSource2
        '
        Me.AuthorsBindingSource2.DataMember = "authors"
        Me.AuthorsBindingSource2.DataSource = Me.DsEjercicio6
        '
        'DsEjercicio6
        '
        Me.DsEjercicio6.DataSetName = "dsEjercicio6"
        Me.DsEjercicio6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'AuthorsTableAdapter2
        '
        Me.AuthorsTableAdapter2.ClearBeforeFill = True
        '
        'EmployeesTableAdapter1
        '
        Me.EmployeesTableAdapter1.ClearBeforeFill = True
        '
        'AuthorsTableAdapter1
        '
        Me.AuthorsTableAdapter1.ClearBeforeFill = True
        '
        'EmployeesTableAdapter
        '
        Me.EmployeesTableAdapter.ClearBeforeFill = True
        '
        'AuthorsTableAdapter
        '
        Me.AuthorsTableAdapter.ClearBeforeFill = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1398, 1061)
        Me.Controls.Add(Me.DataGridView5)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.DataGridView4)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AuthorsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAuthors, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsEmployeesNS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AuthorsBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAuthorsEjercicio3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeesBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsEjercicio4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AuthorsBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsEjercicio6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DsAuthors As Conectores_Tarea03.dsAuthors
    Friend WithEvents AuthorsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents AuthorsTableAdapter As Conectores_Tarea03.dsAuthorsTableAdapters.authorsTableAdapter
    Friend WithEvents AuidDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AulnameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AufnameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhoneDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ZipDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ContractDataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents DsEmployeesNS As Conectores_Tarea03.dsEmployeesNS
    Friend WithEvents EmployeesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EmployeesTableAdapter As Conectores_Tarea03.dsEmployeesNSTableAdapters.EmployeesTableAdapter
    Friend WithEvents EmployeeIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FirstNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TitleDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TitleOfCourtesyDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BirthDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HireDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RegionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PostalCodeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CountryDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HomePhoneDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExtensionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhotoDataGridViewImageColumn As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents NotesDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReportsToDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhotoPathDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents DsAuthorsEjercicio3 As Conectores_Tarea03.dsAuthorsEjercicio3
    Friend WithEvents AuthorsBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents AuthorsTableAdapter1 As Conectores_Tarea03.dsAuthorsEjercicio3TableAdapters.authorsTableAdapter
    Friend WithEvents AuidDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AulnameDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AufnameDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhoneDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StateDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ZipDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ContractDataGridViewCheckBoxColumn1 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents DsEjercicio4 As Conectores_Tarea03.dsEjercicio4
    Friend WithEvents EmployeesBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents EmployeesTableAdapter1 As Conectores_Tarea03.dsEjercicio4TableAdapters.EmployeesTableAdapter
    Friend WithEvents EmployeeIDDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastNameDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FirstNameDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TitleDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TitleOfCourtesyDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BirthDateDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HireDateDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RegionDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PostalCodeDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CountryDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HomePhoneDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExtensionDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhotoDataGridViewImageColumn1 As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents NotesDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReportsToDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhotoPathDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents DataGridView5 As System.Windows.Forms.DataGridView
    Friend WithEvents DsEjercicio6 As Conectores_Tarea03.dsEjercicio6
    Friend WithEvents AuthorsBindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents AuthorsTableAdapter2 As Conectores_Tarea03.dsEjercicio6TableAdapters.authorsTableAdapter
    Friend WithEvents AuidDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AulnameDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AufnameDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhoneDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AddressDataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StateDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ZipDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ContractDataGridViewCheckBoxColumn2 As System.Windows.Forms.DataGridViewCheckBoxColumn

End Class
