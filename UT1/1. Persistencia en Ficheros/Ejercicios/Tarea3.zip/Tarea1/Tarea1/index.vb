﻿Public Class index

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        frnTarea1.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        frnTarea2.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        frnTarea3.ShowDialog()
    End Sub
End Class